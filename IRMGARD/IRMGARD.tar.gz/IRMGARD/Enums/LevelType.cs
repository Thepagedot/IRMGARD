﻿using System;

namespace IRMGARD
{
	public enum LevelType
	{
		HearMe,
		FourPictures,
		LetterDrop,
		FindMissingLetter,
		PickSyllable,
		BuildSyllable,
		HearTheLetter,
		HearMeAbc,
		AbcRank,
		Memory
	}
}

